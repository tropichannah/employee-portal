import java.util.Scanner;

public class ConsoleUI {

    private IEmployeeService employeeService = new EmployeeService();
    private IReportService reportService = new ReportService(employeeService);
    private final Scanner userInput = new Scanner(System.in);

    public void displayMainMenu() {

        while (true) {

            System.out.println("======== Employee Management System ========");
            System.out.println("1) Add Employee");
            System.out.println("2) Search Employee");
            System.out.println("3) Update Employee");
            System.out.println("4) Generate Reports");
            System.out.println("5) Exit");

            String choice = getUserInput("Enter choice: ");

            switch (choice) {
                case "1" -> handleAddEmployee();
                case "2" -> handleSearchEmployee();
                case "3" -> handleUpdateEmployee();
                case "4" -> handleGenerateReports();
                case "5" -> {
                    System.out.println("Exiting system...");
                    return;
                }
                default -> System.out.println("Invalid input. Try again.");
            }

            System.out.println();
        }
    }

    // menu option 1
    private void handleAddEmployee() {

        System.out.println("=========== Add Employee ===========");

        try {
            String fName = getUserInput("Enter First Name: ");
            String lName = getUserInput("Enter Last Name: ");
            String email = getUserInput("Enter Email: ");
            String hireDateStr = getUserInput("Enter Hire Date (yyyy-mm-dd): ");
            String salaryStr = getUserInput("Enter Salary: ");
            String ssn = getUserInput("Enter SSN (no dashes): ");
            String jobTitle = getUserInput("Enter Job Title: ");
            String division = getUserInput("Enter Division: ");

            double salary = Double.parseDouble(salaryStr);
            java.sql.Date hireDate;
            try {
                hireDate = java.sql.Date.valueOf(hireDateStr);
            } catch (Exception ex) {
                throw new Exception("Invalid hire date. Use yyyy-mm-dd.");
            }
            // build employee object
            Employee emp = new Employee();
            emp.setFirstName(fName);
            emp.setLastName(lName);
            emp.setEmail(email);
            emp.setHireDate(hireDate);
            emp.setSalary(salary);
            emp.setSsn(ssn);

            // insert employee (business logic is centralized in employee service)
            employeeService.addEmployee(emp);

            // Fetch the new empID - this is needed to add new job title and division if it
            // doesn't exist and to print the summary of newly added employee
            int empID = employeeService.searchEmployees("ssn", ssn).get(0).getEmpID();

            // JobTitle and/or Division may not exist, if so, insert a new value in those tables
            int jobTitleID = employeeService.getOrCreateJobTitle(jobTitle);
            int divisionID = employeeService.getOrCreateDivision(division);

            // update the linking table for job title and division
            employeeService.assignJobTitle(empID, jobTitleID);
            employeeService.assignDivision(empID, divisionID);

            System.out.println("Employee added successfully.");

            // print the new employee summary
            var savedEmp = employeeService.searchEmployees("id", String.valueOf(empID)).get(0);

            System.out.println("----------- Employee Summary -----------");
            displayEmployee(savedEmp);
            System.out.println("Job Title:   " + jobTitle);
            System.out.println("Division:    " + division);
            System.out.println("----------------------------------------\n");

        } catch (Exception e) {
            System.out.println("Failed to add employee: " + e.getMessage());
        }

        System.out.println();
    }

    // menu option 2
    private void handleSearchEmployee() {

        while (true) {
            System.out.println("=========== Search Employee ===========");
            System.out.println("1) Search by Employee ID");
            System.out.println("2) Search by Name");
            System.out.println("3) Search by SSN");
            System.out.println("4) Return to Main Menu");

            String choice = getUserInput("Enter choice: ");

            try {
                switch (choice) {
                    case "1" -> searchByID();
                    case "2" -> searchByName();
                    case "3" -> searchBySSN();
                    case "4" -> {
                        return;
                    } // exit search submenu
                    default -> System.out.println("Invalid option");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            System.out.println();
        }
    }

    // search submenu handlers
    // serach submenu option 1
    private void searchByID() throws Exception {
        String id = getUserInput("Enter Employee ID: ");

        var results = employeeService.searchEmployees("id", id);

        if (results.isEmpty()) {
            System.out.println("No employee found.");
            return;
        }

        for (Employee emp : results) {
            displayEmployee(emp);
        }
    }

    // serach submenu option 2
    private void searchByName() throws Exception {
        String name = getUserInput("Enter name (first or last): ");

        var results = employeeService.searchEmployees("name", name);

        if (results.isEmpty()) {
            System.out.println("No employee found.");
            return;
        }

        for (Employee emp : results) {
            displayEmployee(emp);
        }
    }

    // serach submenu option 3
    private void searchBySSN() throws Exception {
        String ssn = getUserInput("Enter SSN (no dashes): ");

        var results = employeeService.searchEmployees("ssn", ssn);

        if (results.isEmpty()) {
            System.out.println("No employee found.");
            return;
        }

        for (Employee emp : results) {
            displayEmployee(emp);
        }
    }

    // display employee search result
    private void displayEmployee(Employee emp) {
        System.out.println("--------------------------------");
        System.out.println("Employee ID: " + emp.getEmpID());
        System.out.println("Name: " + emp.getFirstName() + " " + emp.getLastName());
        System.out.println("Email: " + emp.getEmail());
        System.out.println("Hire Date: " + emp.getHireDate());
        System.out.println("Salary: " + emp.getSalary());
        System.out.println("SSN: " + emp.getSsn());
    }

    // menu option 3
    private void handleUpdateEmployee() {

        while (true) {
            System.out.println("=========== Update Employee ===========");
            System.out.println("1) Update Employee Data");
            System.out.println("2) Update Salary by Pay Range");
            System.out.println("3) Return to Main Menu");

            String choice = getUserInput("Enter choice: ");

            switch (choice) {
                case "1" -> updateEmployeeData();
                case "2" -> handleSalaryRangeUpdate();
                case "3" -> { return; }
                default -> System.out.println("Invalid choice.");
            }

            System.out.println();
        }
    }

    // submenu option 1 update employee data 
    private void updateEmployeeData() {
        System.out.println("=========== Update Employee Data ===========");
        int empID;

        try {
            // validation to ensure it's an int
            empID = Integer.parseInt(getUserInput("Enter Employee ID: "));
        } catch (Exception e) {
            System.out.println("Invalid ID.");
            return;
        }

        Employee emp;
        try {
            var results = employeeService.searchEmployees("id", String.valueOf(empID));
            if (results.isEmpty()) {
                System.out.println("Employee not found.");
                return;
            }
            emp = results.get(0);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return;
        }

        // submenu to prompt for which field to update
        while (true) {
            System.out.println("------ Update Menu for Employee " + empID + " ------");
            System.out.println("1) First Name");
            System.out.println("2) Last Name");
            System.out.println("3) Email");
            System.out.println("4) Hire Date");
            System.out.println("5) Salary");
            System.out.println("6) SSN");
            System.out.println("7) Job Title");
            System.out.println("8) Division");
            System.out.println("9) Return to Previous Menu");

            String choice = getUserInput("Choose field to update: ");

            try {
                switch (choice) {

                    case "1" -> {
                        emp.setFirstName(getUserInput("New First Name: "));
                        employeeService.updateEmployee(emp);
                        System.out.println("First name updated.");
                    }

                    case "2" -> {
                        emp.setLastName(getUserInput("New Last Name: "));
                        employeeService.updateEmployee(emp);
                        System.out.println("Last name updated.");
                    }

                    case "3" -> {
                        emp.setEmail(getUserInput("New Email: "));
                        employeeService.updateEmployee(emp);
                        System.out.println("Email updated.");
                    }

                    case "4" -> {
                        String raw = getUserInput("New Hire Date (yyyy-mm-dd): ");
                        try {
                            emp.setHireDate(java.sql.Date.valueOf(raw));
                        } catch (Exception ex) {
                            throw new Exception("Invalid Hire Date. Use yyyy-mm-dd.");
                        }
                        employeeService.updateEmployee(emp);
                        System.out.println("Hire date updated.");
                    }

                    case "5" -> {
                        emp.setSalary(Double.parseDouble(getUserInput("New Salary: ")));
                        employeeService.updateEmployee(emp);
                        System.out.println("Salary updated.");
                    }

                    case "6" -> {
                        emp.setSsn(getUserInput("New SSN (no dashes): "));
                        employeeService.updateEmployee(emp);
                        System.out.println("SSN updated.");
                    }

                    case "7" -> {
                        String jt = getUserInput("New Job Title: ");
                        employeeService.updateEmployeeJobTitle(empID, jt);
                        System.out.println("Job Title updated.");
                    }

                    case "8" -> {
                        String dv = getUserInput("New Division: ");
                        employeeService.updateEmployeeDivision(empID, dv);
                        System.out.println("Division updated.");
                    }

                    case "9" -> {
                        return;
                    }

                    default -> System.out.println("Invalid choice.");
                }

            } catch (Exception e) {
                System.out.println("Update error: " + e.getMessage());
            }

            System.out.println();
        }
    }

    // update employee submenu option 2
    private void handleSalaryRangeUpdate() {
        try {
            System.out.println("=== Salary Adjustment by Range ===");

            double min = Double.parseDouble(getUserInput("Enter lower end of salary range: "));
            double max = Double.parseDouble(getUserInput("Enter higher end of salary range: "));
            double percent = Double.parseDouble(getUserInput("Enter percent change (example 0.10 for 10 percent increase or -0.05 for 5 percent decrease): "));

            int updated = employeeService.updateSalaryByRange(min, max, percent);

            System.out.println(updated + " employees had their salary updated.");
        } catch (Exception e) {
            System.out.println("Error updating salaries: " + e.getMessage());
        }
    }

    // menu option 4
    private void handleGenerateReports() {

        while (true) {
            System.out.println("======= Reports =======");
            System.out.println("1) Employee Pay History");
            System.out.println("2) Total Pay by Job Title");
            System.out.println("3) Total Pay by Division");
            System.out.println("4) Return to Main Menu");

            String choice = getUserInput("Enter report type: ");

            try {
                switch (choice) {
                    case "1" -> handlePayHistoryReport();
                    case "2" -> handlePayByJobTitleReport();
                    case "3" -> handlePayByDivisionReport();
                    case "4" -> {
                        return;
                    } // exits the submenu
                    default -> System.out.println("Invalid choice");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            System.out.println();
        }
    }

    // report submenu option 1
    private void handlePayHistoryReport() throws Exception {
        int id = Integer.parseInt(getUserInput("Enter Employee ID: "));
        // business logic in reportService
        String report = reportService.getEmployeePayHistoryReport(id);
        System.out.println(report);
    }

    // report submenu option 2
    private void handlePayByJobTitleReport() throws Exception {
        String title = getUserInput("Enter Job Title: ");
        // business logic in reportService
        String report = reportService.getTotalPayByJobTitleReport(title);
        System.out.println(report);
    }

    // report submenu option 3
    private void handlePayByDivisionReport() throws Exception {
        String div = getUserInput("Enter Division Name: ");
        // business logic in reportService
        String report = reportService.getTotalPayByDivisionReport(div);
        System.out.println(report);
    }

    // helper to prompt for user input
    private String getUserInput(String prompt) {
        System.out.println();
        System.out.print(prompt);
        return userInput.nextLine().trim();
    }
}