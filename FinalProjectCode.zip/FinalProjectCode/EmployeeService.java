import java.util.List;

public class EmployeeService implements IEmployeeService {

    private final EmployeeDAO dao = new EmployeeDAO();

    @Override
    public void addEmployee(Employee emp) throws Exception {
        
        // first name and last name fields can't be blank
        if (emp.getFirstName() == null || emp.getFirstName().isBlank()) {
            throw new Exception("First name cannot be empty.");
        }

        if (emp.getLastName() == null || emp.getLastName().isBlank()) {
            throw new Exception("Last name cannot be empty.");
        }

        // proper email address validation
        if (!emp.getEmail().contains("@")) {
            throw new Exception("Email must contain @.");
        }

        // SSN validations
        validateSSN(emp.getSsn());
        
        dao.insertEmployee(emp);
    }

    @Override
    public List<Employee> searchEmployees(String type, String value) throws Exception {

        // enforce search value not empty
        if (value == null || value.trim().isEmpty()) {
            throw new Exception("Search value cannot be empty.");
        }

        return dao.search(type, value);
    }

    @Override
    public void updateEmployee(Employee emp) throws Exception {
        
        // proper email address validation
        if (!emp.getEmail().contains("@")) {
            throw new Exception("Email must contain @.");
        }

        // SSN validations
        validateSSN(emp.getSsn());

        // Salary must be positive
        if (emp.getSalary() <= 0) {
            throw new Exception("Salary must be greater than zero.");
        }

        dao.updateEmployee(emp);
    }

    @Override
    public int updateSalaryByRange(double min, double max, double percent) throws Exception {

        // salary range should be reasonable
        if (min < 0 || max < 0 || min >= max) {
            throw new Exception("Invalid salary range.");
        }

        // percentage should be reasonable (set between -50 percent and +50 percent)
        if (percent < -0.5 || percent > 0.5) {
            throw new Exception("Percent adjustment must be between -0.5 and 0.5.");
        }

        return dao.updateSalaryByRange(min, max, percent);
    }

    public List<PayStatement> getPayStatementsForEmployee(int empID) throws Exception {

        // Verify employee exists
        var employees = searchEmployees("id", String.valueOf(empID));
        if (employees.isEmpty()) {
            throw new Exception("Employee not found.");
        }

        return dao.getPayStatementsForEmployee(empID);
    }

    public List<Employee> getEmployeesByJobTitle(String jobTitle) throws Exception {

        if (jobTitle == null || jobTitle.isBlank()) {
            throw new Exception("Job title cannot be empty");
        }

        return dao.getEmployeesByJobTitle(jobTitle);
    }

    public List<Employee> getEmployeesByDivision(String divisionName) throws Exception {

        if (divisionName == null || divisionName.isBlank()) {
            throw new Exception("Division name cannot be empty");
        }

        return dao.getEmployeesByDivision(divisionName);
    }

    public String getJobTitleForEmployee(int empID) throws Exception {
        return dao.getJobTitleForEmployee(empID);
    }

    public int getOrCreateJobTitle(String title) throws Exception {
        return dao.getOrCreateJobTitle(title);
    }

    public int getOrCreateDivision(String division) throws Exception {
        return dao.getOrCreateDivision(division);
    }

    public void assignJobTitle(int empID, int jobTitleID) throws Exception {
        dao.addEmployeeJobTitle(empID, jobTitleID);
    }

    public void assignDivision(int empID, int divisionID) throws Exception {
        dao.addEmployeeDivision(empID, divisionID);
    }

    public void updateEmployeeJobTitle(int empID, String newJobTitle) throws Exception {
        int jtID = dao.getOrCreateJobTitle(newJobTitle);
        dao.updateEmployeeJobTitle(empID, jtID);
    }

    public void updateEmployeeDivision(int empID, String newDivision) throws Exception {
        int divID = dao.getOrCreateDivision(newDivision);
        dao.updateEmployeeDivision(empID, divID);
    }
    
    private void validateSSN(String ssn) throws Exception {

        if (ssn == null || ssn.isBlank()) {
            throw new Exception("SSN cannot be empty.");
        }

        if (ssn.contains("-")) {
            throw new Exception("SSN should not contain dashes.");
        }

        if (!ssn.matches("\\d{9}")) {
            throw new Exception("SSN must be exactly 9 digits.");
        }
    }
}