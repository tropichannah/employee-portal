import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class Employee {

    private int empID;
    private String firstName;
    private String lastName;
    private String email;
    private Date hireDate;
    private double salary;
    private String ssn;

    // needed for JDBC reconstruction in searchEmployees
    public Employee() {}

    //  constructor for inserts or external creation
    public Employee(int empID, String firstName, String lastName,
                    String email, Date hireDate, double salary, String ssn) {

        this.empID = empID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.hireDate = hireDate;
        this.salary = salary;
        this.ssn = ssn;
    }

    // ========= GETTERS =========
    public int getEmpID() { return empID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }
    public Date getHireDate() { return hireDate; }
    public double getSalary() { return salary; }
    public String getSsn() { return ssn; }

    // ========= SETTERS =========
    public void setEmpID(int empID) { this.empID = empID; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public void setEmail(String email) { this.email = email; }
    public void setHireDate(Date hireDate) { this.hireDate = hireDate; }
    public void setSalary(double salary) { this.salary = salary; }
    public void setSsn(String ssn) { this.ssn = ssn; }

    // ========= For REPORTS =========
    private List<PayStatement> payStatements = new ArrayList<>();

    public List<PayStatement> getPayStatements() {
        return payStatements;
    }

    public void addPayStatement(PayStatement ps) {
        payStatements.add(ps);
    }
}