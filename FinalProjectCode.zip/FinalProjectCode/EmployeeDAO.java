import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    // main search 
    public List<Employee> search(String type, String value) throws Exception {

        List<Employee> list = new ArrayList<>();

        String sqlQuery;

        switch (type) {
            case "id" -> sqlQuery = "SELECT * FROM employees WHERE empid = ?";
            case "name" -> sqlQuery = "SELECT * FROM employees WHERE Fname LIKE ? OR Lname LIKE ?";
            case "ssn" -> sqlQuery = "SELECT * FROM employees WHERE SSN = ?";
            default -> throw new IllegalArgumentException("Invalid search type: " + type);
        }

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sqlQuery)) {

            if (type.equals("name")) {
                stmt.setString(1, "%" + value + "%");
                stmt.setString(2, "%" + value + "%");
            } else {
                stmt.setString(1, value);
            }

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(mapEmployee(rs));
            }
        }

        return list;
    }

    // add new employee 
    public void insertEmployee(Employee emp) throws Exception {
        String sql = "INSERT INTO employees (Fname, Lname, email, HireDate, salary, SSN) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, emp.getFirstName());
            stmt.setString(2, emp.getLastName());
            stmt.setString(3, emp.getEmail());
            stmt.setDate(4, new java.sql.Date(emp.getHireDate().getTime()));
            stmt.setDouble(5, emp.getSalary());
            stmt.setString(6, emp.getSsn());

            stmt.executeUpdate();
        }
    }

    // search by SSN for validation
    public Employee findBySSN(String ssn) throws Exception {
        String sqlQuery = "SELECT * FROM employees WHERE SSN = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sqlQuery)) {

            stmt.setString(1, ssn);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapEmployee(rs);
            }
        }

        return null;
    }

    private Employee mapEmployee(ResultSet rs) throws SQLException {
        return new Employee(
                rs.getInt("empid"),
                rs.getString("Fname"),
                rs.getString("Lname"),
                rs.getString("email"),
                rs.getDate("HireDate"),
                rs.getDouble("salary"),
                rs.getString("SSN"));
    }

    // update existing employee record
    public void updateEmployee(Employee emp) throws Exception {
        String sql = "UPDATE employees SET Fname=?, Lname=?, email=?, HireDate=?, salary=?, SSN=? WHERE empid=?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, emp.getFirstName());
            stmt.setString(2, emp.getLastName());
            stmt.setString(3, emp.getEmail());
            // must use getTime to prevent data type mismatch issue
            stmt.setDate(4, new java.sql.Date(emp.getHireDate().getTime()));
            stmt.setDouble(5, emp.getSalary());
            stmt.setString(6, emp.getSsn());
            stmt.setInt(7, emp.getEmpID());

            stmt.executeUpdate();
        }
    }

    // update salary by range provided using a percentage (calculated at business layeer)
    public int updateSalaryByRange(double min, double max, double percent) throws Exception {
        String sql = "UPDATE employees SET salary = salary * ? WHERE salary >= ? AND salary < ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, 1 + percent);
            stmt.setDouble(2, min);
            stmt.setDouble(3, max);

            return stmt.executeUpdate();
        }
    }

    // retrieve an employee pay statement for ereports
    public List<PayStatement> getPayStatementsForEmployee(int empID) throws Exception {

        String sql = "SELECT * FROM payroll WHERE empid = ? ORDER BY PayDate";

        List<PayStatement> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, empID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                PayStatement ps = new PayStatement();
                ps.setPayID(rs.getInt("payID"));
                ps.setPayDate(rs.getDate("PayDate"));
                ps.setEarnings(rs.getDouble("earnings"));
                ps.setFedTax(rs.getDouble("fed_tax"));
                ps.setFedMed(rs.getDouble("fed_med"));
                ps.setFedSS(rs.getDouble("fed_SS"));
                ps.setStateTax(rs.getDouble("state_tax"));
                ps.setRetire401k(rs.getDouble("retire_401k"));
                ps.setHealthCare(rs.getDouble("health_care"));
                list.add(ps);
            }
        }

        return list;
    }

    // get the employees by job title for reports
    public List<Employee> getEmployeesByJobTitle(String jobTitle) throws Exception {

        String sql = """
                    SELECT e.*
                    FROM employees e
                    JOIN employee_job_titles ejt ON e.empid = ejt.empid
                    JOIN job_titles jt ON ejt.job_title_id = jt.job_title_id
                    WHERE jt.job_title = ?
                """;

        List<Employee> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, jobTitle);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(mapEmployee(rs));
            }
        }

        return list;
    }

    // get the employees by division for reports
    public List<Employee> getEmployeesByDivision(String divisionName) throws Exception {

        String sql = """
                    SELECT e.*
                    FROM employees e
                    JOIN employee_division ed ON e.empid = ed.empid
                    JOIN division d ON ed.div_ID = d.id
                    WHERE d.Name = ?
                """;

        List<Employee> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, divisionName);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(mapEmployee(rs));
            }
        }

        return list;
    }

    // get the job title for employee for reports
    public String getJobTitleForEmployee(int empID) throws Exception {

        String sql = """
                    SELECT jt.job_title
                    FROM job_titles jt
                    JOIN employee_job_titles ejt ON ejt.job_title_id = jt.job_title_id
                    WHERE ejt.empid = ?
                """;

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, empID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("job_title");
            }
        }

        return "N/A"; // return something if no job title assigned
    }


    public int getOrCreateJobTitle(String jobTitle) throws Exception {
        String findSql = "SELECT job_title_id FROM job_titles WHERE job_title = ?";
        String insertSql = "INSERT INTO job_titles (job_title) VALUES (?)";

        try (Connection conn = DatabaseConnection.getConnection()) {

            // check if exists first
            try (PreparedStatement stmt = conn.prepareStatement(findSql)) {
                stmt.setString(1, jobTitle);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt("job_title_id");
                }
            }

            // if job title doesn't exist, insert new
            try (PreparedStatement stmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, jobTitle);
                stmt.executeUpdate();

                ResultSet keys = stmt.getGeneratedKeys();
                if (keys.next())
                    return keys.getInt(1);
            }
        }

        throw new Exception("Failed to insert job title.");
    }

    public int getOrCreateDivision(String divisionName) throws Exception {
        String findSql = "SELECT id FROM division WHERE Name = ?";
        String insertSql = "INSERT INTO division (id, Name) VALUES (NULL, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {

            // check if exists
            try (PreparedStatement stmt = conn.prepareStatement(findSql)) {
                stmt.setString(1, divisionName);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }

            // if division doesn't exist, insert new
            try (PreparedStatement stmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, divisionName);
                stmt.executeUpdate();

                ResultSet keys = stmt.getGeneratedKeys();
                if (keys.next())
                    return keys.getInt(1);
            }
        }

        throw new Exception("Failed to insert division.");
    }

    // 
    public void addEmployeeJobTitle(int empID, int jobTitleID) throws Exception {
        String sql = "INSERT INTO employee_job_titles (empid, job_title_id) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, empID);
            stmt.setInt(2, jobTitleID);
            stmt.executeUpdate();
        }
    }

    public void addEmployeeDivision(int empID, int divisionID) throws Exception {
        String sql = "INSERT INTO employee_division (empid, div_ID) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, empID);
            stmt.setInt(2, divisionID);
            stmt.executeUpdate();
        }
    }

    public void updateEmployeeJobTitle(int empID, int jobTitleID) throws Exception {
        String deleteSql = "DELETE FROM employee_job_titles WHERE empid = ?";
        String insertSql = "INSERT INTO employee_job_titles (empid, job_title_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {

            // clear old job title
            try (PreparedStatement stmt = conn.prepareStatement(deleteSql)) {
                stmt.setInt(1, empID);
                stmt.executeUpdate();
            }

            // set new job title link to employee
            try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
                stmt.setInt(1, empID);
                stmt.setInt(2, jobTitleID);
                stmt.executeUpdate();
            }
        }
    }

    public void updateEmployeeDivision(int empID, int divisionID) throws Exception {
        String deleteSql = "DELETE FROM employee_division WHERE empid = ?";
        String insertSql = "INSERT INTO employee_division (empid, div_ID) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {

            // clear old division
            try (PreparedStatement stmt = conn.prepareStatement(deleteSql)) {
                stmt.setInt(1, empID);
                stmt.executeUpdate();
            }

            // insert new division link to employee
            try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
                stmt.setInt(1, empID);
                stmt.setInt(2, divisionID);
                stmt.executeUpdate();
            }
        }
    }
}