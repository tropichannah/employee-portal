public class EmployeeSystemApp {

    public static void main(String[] args) {

        ConsoleUI ui = new ConsoleUI();
        // initialize the menu
        ui.displayMainMenu();
    }
}