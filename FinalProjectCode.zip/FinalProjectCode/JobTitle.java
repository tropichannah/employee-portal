public class JobTitle {

    private int jobTitleID;
    private String title;

    public int getJobTitleID() { return jobTitleID; }
    public void setJobTitleID(int id) { this.jobTitleID = id; }

    public String getJobTitle() { return title; }
    public void setTitle(String t) { this.title = t; }
    
}