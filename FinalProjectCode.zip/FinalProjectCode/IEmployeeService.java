import java.util.List;

public interface IEmployeeService {

    void addEmployee(Employee emp) throws Exception;

    List<Employee> searchEmployees(String criteriaType, String value) throws Exception;

    void updateEmployee(Employee emp) throws Exception;

    int updateSalaryByRange(double min, double max, double percent) throws Exception;

    // methods we did not realize might have been needed to be exposed in the design phase
    List<PayStatement> getPayStatementsForEmployee(int empID) throws Exception;

    List<Employee> getEmployeesByJobTitle(String jobTitle) throws Exception;

    List<Employee> getEmployeesByDivision(String divisionName) throws Exception;

    String getJobTitleForEmployee(int empID) throws Exception;

    int getOrCreateJobTitle(String jobTitle) throws Exception;

    int getOrCreateDivision(String divisionName) throws Exception;

    void assignJobTitle(int empID, int jobTitleID) throws Exception;

    void assignDivision(int empID, int divisionID) throws Exception;

    void updateEmployeeJobTitle(int empID, String newJobTitle) throws Exception;

    void updateEmployeeDivision(int empID, String newDivision) throws Exception;
}