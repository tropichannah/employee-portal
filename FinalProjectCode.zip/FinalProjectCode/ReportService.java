public class ReportService implements IReportService {

    private final IEmployeeService employeeService;
    // report builder formatting constant
    private static final int REPORT_WIDTH = 66;

    public ReportService(IEmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public String getEmployeePayHistoryReport(int empID) throws Exception {

        var employees = employeeService.searchEmployees("id", String.valueOf(empID));

        if (employees.isEmpty()) {
            return buildReport("Employee Pay History", "Employee not found.");
        }

        var employee = employees.get(0);
        var statements = employeeService.getPayStatementsForEmployee(empID);

        if (statements.isEmpty()) {
            return buildReport("Employee Pay History", "No pay statements available.");
        }

        StringBuilder body = new StringBuilder();
        body.append("Employee: ")
            .append(employee.getFirstName()).append(" ").append(employee.getLastName())
            .append("\n").append("EmployeeID: ").append(employee.getEmpID()).append("\n\n");

        // header row
        body.append(String.format("%-8s %-18s %-20s %-20s\n","PayID", "Date", "Gross", "Net"))
        .append("-".repeat(REPORT_WIDTH)).append("\n");

        // display data retrieved
        for (PayStatement ps : statements) {
            body.append(ps.getPaymentDetails()).append("\n");
        }

        return buildReport("Employee Pay History", body.toString());
    }

    @Override
    public String getTotalPayByJobTitleReport(String jobTitle) throws Exception {

        var employees = employeeService.getEmployeesByJobTitle(jobTitle);

        if (employees.isEmpty()) {
            return buildReport("Total Pay by Job Title",
                    "No employees found for job title: " + jobTitle);
        }

        // calculate total salary to display at bottom
        double total = 0;
        for (Employee e : employees) {
            total += e.getSalary();
        }

        StringBuilder body = new StringBuilder();

        body.append("Job Title: ").append(jobTitle).append("\n\n");

        // header row
        body.append(String.format("%-8s %-42s %-16s\n",
                "ID", "Employee Name", "Salary"))
                .append("-".repeat(REPORT_WIDTH)).append("\n");

        // display data retrieved
        for (Employee e : employees) {
            String fullName = e.getFirstName() + " " + e.getLastName();
            body.append(String.format("%-8d %-42s %-16.2f\n",
                    e.getEmpID(), fullName, e.getSalary()));
        }

        // Total row
        body.append("\n")
            .append(String.format("%-50s %-12.2f\n",
                    "Total Salary:", total));

        return buildReport("Total Pay by Job Title", body.toString());
    }
    
    @Override
    public String getTotalPayByDivisionReport(String divisionName) throws Exception {

        var employees = employeeService.getEmployeesByDivision(divisionName);

        if (employees.isEmpty()) {
            return buildReport("Total Pay by Division",
                    "No employees found for division: " + divisionName);
        }

        double total = 0;

        StringBuilder body = new StringBuilder();

        body.append("Division: ").append(divisionName).append("\n\n");

        // header row 
        body.append(String.format("%-8s %-20s %-20s %-12s\n",
                "ID", "Employee Name", "Job Title", "Salary"))
                .append("-".repeat(REPORT_WIDTH)).append("\n");

        // display data rows retrieved
        for (Employee e : employees) {

            String fullName = e.getFirstName() + " " + e.getLastName();
            String jobTitle = employeeService.getJobTitleForEmployee(e.getEmpID());

            body.append(String.format("%-8d %-20s %-20s %-12.2f\n",
                    e.getEmpID(),
                    fullName,
                    jobTitle,
                    e.getSalary()
            ));

            total += e.getSalary();
        }

        // Total row
        body.append("\n")
            .append(String.format("%-50s %-12.2f\n",
                    "Total Salary:", total));

        return buildReport("Total Pay by Division", body.toString());
    }


    private String buildReport(String title, String body) {

        // pretty formatting
        String border = "=".repeat(REPORT_WIDTH);
        String footer = "-".repeat(REPORT_WIDTH);

        // center title visually
        int padding = (REPORT_WIDTH - title.length()) / 2;
        String centeredTitle = " ".repeat(Math.max(padding, 0)) + title;

        StringBuilder sb = new StringBuilder();

        sb.append(border).append("\n");
        sb.append(centeredTitle).append("\n");
        sb.append(border).append("\n");
        sb.append(body).append("\n");
        sb.append(footer).append("\n");
        sb.append("Report generated: ").append(java.time.LocalDate.now())
        .append(" ").append(java.time.LocalTime.now())
        .append("\n");

        return sb.toString();
    }
}