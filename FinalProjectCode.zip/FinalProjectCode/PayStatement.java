import java.util.Date;

public class PayStatement {

    private int payID;
    private Date payDate;
    private double earnings;
    private double fedTax;
    private double fedMed;
    private double fedSS;
    private double stateTax;
    private double retire401k;
    private double healthCare;

    // ======= GETTERS =======

    public int getPayID() { return payID; }
    public Date getPayDate() { return payDate; }
    public double getEarnings() { return earnings; }
    public double getFedTax() { return fedTax; }
    public double getFedMed() { return fedMed; }
    public double getFedSS() { return fedSS; }
    public double getStateTax() { return stateTax; }
    public double getRetire401k() { return retire401k; }
    public double getHealthCare() { return healthCare; }

    // ======= SETTERS =======

    public void setPayID(int id) { this.payID = id; }
    public void setPayDate(Date d) { this.payDate = d; }
    public void setEarnings(double e) { this.earnings = e; }
    public void setFedTax(double fedTax) { this.fedTax = fedTax; }
    public void setFedMed(double fedMed) { this.fedMed = fedMed; }
    public void setFedSS(double fedSS) { this.fedSS = fedSS; }
    public void setStateTax(double stateTax) { this.stateTax = stateTax; }
    public void setRetire401k(double retire401k) { this.retire401k = retire401k; }
    public void setHealthCare(double healthCare) { this.healthCare = healthCare; }

    // ======= For reports =======

    public double getNetPayment() {
        return earnings - (fedTax + fedMed + fedSS + stateTax + retire401k + healthCare);
    }

    public String getPaymentDetails() {
        return String.format("%-8d %-18s %-20.2f %-20.2f",
                payID,
                formatDate(payDate),
                earnings,
                getNetPayment());
    }

    // helper for consistent date format
    private String formatDate(Date d) {
    return new java.text.SimpleDateFormat("yyyy-MM-dd").format(d);
}
}