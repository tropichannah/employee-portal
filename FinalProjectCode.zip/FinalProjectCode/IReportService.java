public interface IReportService {

    String getEmployeePayHistoryReport(int empID) throws Exception;

    String getTotalPayByJobTitleReport(String jobTitle) throws Exception;

    String getTotalPayByDivisionReport(String divisionName) throws Exception;
}