public class Division {

    private int divisionID;
    private String name;

    public int getDivisionID() { return divisionID; }
    public String getDivisionName() { return name; }

    public void setDivisionID(int id) { this.divisionID = id; }
    public void setName(String n) { this.name = n; }

}